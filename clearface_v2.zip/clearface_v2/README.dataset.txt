# clearface > 2025-01-15 2:31pm
https://universe.roboflow.com/face-image/clearface-bvile

Provided by a Roboflow user
License: CC BY 4.0

