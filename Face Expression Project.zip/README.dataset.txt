# Face Expression Project > 2025-01-09 11:00pm
https://universe.roboflow.com/face-image/face-expression-project

Provided by a Roboflow user
License: CC BY 4.0

